# User Management System

### Project is deployed on following link :
# http://13.127.49.192:3000/

In this project, we are going to create node CRUD application with express and mongodb. And will export the data to csv file.

#### To Run this project Clone it and install modules using
```
npm install
```

Then Create config.env file and create PORT and MONGO_URI Variable and specify Value.
To execute this project just type
```
npm start
```

